
from .endpoints import app
