{pkgs}: {
  deps = [
    pkgs.vim
  ];
}
